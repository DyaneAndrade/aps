package com.app.servidor;

import com.app.servidor.service.ServidorService;

public class Servidor {

    public static void main(String[] args){
        new ServidorService();
    }
}
